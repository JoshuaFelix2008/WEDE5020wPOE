const accordions = document.querySelectorAll(".accordion");

accordions.forEach(function(button) {

    button.addEventListener("click", function() {

        const panel = this.nextElementSibling;

        if(panel.style.display === "block") {
            panel.style.display = "none";
        }
        else {
            panel.style.display = "block";
        }

    });

});

function showReview() {

    const reviews = [

        "⭐⭐⭐⭐⭐ The meals save me so much time after work.",

        "⭐⭐⭐⭐⭐ Fresh, affordable and delicious.",

        "⭐⭐⭐⭐⭐ My children love the Mac and Cheese.",

        "⭐⭐⭐⭐⭐ Excellent quality and easy to prepare.",

        "⭐⭐⭐⭐⭐ The perfect solution for busy parents."

    ];

    let randomReview =
        Math.floor(Math.random() * reviews.length);

    document.getElementById("reviewText").innerHTML =
        reviews[randomReview];
}

function openLightbox(imageSrc) {

    document.getElementById("lightbox").style.display =
        "block";

    document.getElementById("lightbox-image").src =
        imageSrc;
}

function closeLightbox() {

    document.getElementById("lightbox").style.display =
        "none";
}

function calculateTotal() {

    let mealPrice =
        document.getElementById("meal").value;

    let quantity =
        document.getElementById("quantity").value;

    let total =
        mealPrice * quantity;

    document.getElementById("totalPrice").innerHTML =
        "Total: R" + total;
}


function submitOrder() {

    let name =
        document.getElementById("name").value;

    let email =
        document.getElementById("email").value;

    if (name.trim() === "") {

        alert("Please enter your name.");

        return;
    }

    if (email.trim() === "") {

        alert("Please enter your email address.");

        return;
    }

    document.getElementById("orderMessage").innerHTML =
        "✅ Thank you " + name +
        "! Your order has been submitted successfully.";
}

function searchMeals() {

    let input =
        document.getElementById("searchInput")
        .value.toLowerCase();

    let meals =
        document.querySelectorAll(".meal-card");

    meals.forEach(function(meal) {

        let text =
            meal.textContent.toLowerCase();

        if(text.includes(input)) {

            meal.style.display = "block";

        } else {

            meal.style.display = "none";
        }
    });
}

function submitOrder() {

    let name =
        document.getElementById("name").value;

    let email =
        document.getElementById("email").value;

    if(name === "" || email === "") {

        document.getElementById("errorMessage").innerHTML =
            "Please complete all required fields.";

        return;
    }

    document.getElementById("orderMessage").innerHTML =
        "✅ Order submitted successfully.";

}